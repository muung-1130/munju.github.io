"use client";

import { useEffect, useState } from "react";

type CloudTrailEvent = { eventTime?: string; eventName?: string; eventSource?: string; userIdentity?: { userName?: string; arn?: string } };
type SecurityEventsData = { cloudtrailEvents: CloudTrailEvent[]; vpcFlowLines: string[] };

export default function SecurityDashboard() {
  const [data, setData] = useState<SecurityEventsData | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/security-events")
      .then(async (response) => {
        if (!response.ok) throw new Error("Security logs could not be loaded.");
        return response.json() as Promise<SecurityEventsData>;
      })
      .then(setData)
      .catch((reason: unknown) => setError(reason instanceof Error ? reason.message : "Unknown error"));
  }, []);

  return <main className="space-y-6 p-6">
    <div><p className="text-sm font-medium" style={{ color: "var(--brand)" }}>Security observability</p>
      <h1 className="text-2xl font-semibold" style={{ color: "var(--text-primary)" }}>Security Logs</h1>
      <p className="mt-1 text-sm" style={{ color: "var(--text-muted)" }}>Recent CloudTrail API events and VPC Flow Log records from S3.</p></div>
    {error ? <p role="alert" style={{ color: "var(--status-critical)" }}>{error}</p> : null}
    {!data && !error ? <p style={{ color: "var(--text-muted)" }}>Loading security logs…</p> : null}
    {data ? <div className="grid gap-6 xl:grid-cols-2">
      <section className="rounded-2xl border p-5" style={{ borderColor: "var(--border)", background: "var(--surface-1)" }}>
        <h2 className="text-lg font-semibold" style={{ color: "var(--text-primary)" }}>CloudTrail events</h2><ul className="mt-4 space-y-3">
          {data.cloudtrailEvents.map((event, index) => <li key={`${event.eventTime}-${event.eventName}-${index}`} className="rounded-lg p-3" style={{ background: "var(--surface-2)" }}><p className="font-medium" style={{ color: "var(--text-primary)" }}>{event.eventName ?? "Unknown event"}</p><p className="text-xs" style={{ color: "var(--text-muted)" }}>{event.eventTime ?? "Unknown time"} · {event.eventSource ?? "Unknown source"} · {event.userIdentity?.userName ?? event.userIdentity?.arn ?? "Unknown identity"}</p></li>)}
          {!data.cloudtrailEvents.length ? <li style={{ color: "var(--text-muted)" }}>No recent CloudTrail events.</li> : null}
        </ul></section>
      <section className="rounded-2xl border p-5" style={{ borderColor: "var(--border)", background: "var(--surface-1)" }}>
        <h2 className="text-lg font-semibold" style={{ color: "var(--text-primary)" }}>VPC Flow Logs</h2><ul className="mt-4 space-y-2">
          {data.vpcFlowLines.map((line, index) => <li key={`${line}-${index}`} className="overflow-x-auto rounded-lg p-3 font-mono text-xs" style={{ color: "var(--text-secondary)", background: "var(--surface-2)" }}>{line}</li>)}
          {!data.vpcFlowLines.length ? <li style={{ color: "var(--text-muted)" }}>No recent VPC Flow Log records.</li> : null}
        </ul></section>
    </div> : null}
  </main>;
}
