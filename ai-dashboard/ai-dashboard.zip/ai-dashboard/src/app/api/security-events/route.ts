import { GetObjectCommand, ListObjectsV2Command, S3Client } from "@aws-sdk/client-s3";
import { NextResponse } from "next/server";
import { gunzipSync } from "zlib";

export const runtime = "nodejs";

const REGION = process.env.AWS_REGION ?? "ap-northeast-2";
const s3 = new S3Client({ region: REGION });

const CLOUDTRAIL_BUCKET = process.env.CLOUDTRAIL_LOG_BUCKET ?? "dir-main-cloudtrail-logs-20260814051339588300000002";
const CLOUDTRAIL_PREFIX = process.env.CLOUDTRAIL_LOG_PREFIX ?? "AWSLogs/970307871446/CloudTrail/";
const VPC_FLOW_LOG_BUCKET = process.env.VPC_FLOW_LOG_BUCKET ?? "dir-main-vpc-flow-logs-20260814051339587300000001";
const VPC_FLOW_LOG_PREFIX = process.env.VPC_FLOW_LOG_PREFIX ?? "AWSLogs/970307871446/vpcflowlogs/ap-northeast-2/";

async function getRecentLogs(bucket: string, prefix: string, limit: number): Promise<string[]> {
  const list = await s3.send(new ListObjectsV2Command({ Bucket: bucket, Prefix: prefix, MaxKeys: 50 }));
  const objects = (list.Contents ?? [])
    .filter((item) => item.Key)
    .sort((a, b) => (b.LastModified?.getTime() ?? 0) - (a.LastModified?.getTime() ?? 0))
    .slice(0, limit);

  return Promise.all(objects.map(async ({ Key }) => {
    const object = await s3.send(new GetObjectCommand({ Bucket: bucket, Key }));
    const bytes = await object.Body?.transformToByteArray();
    return bytes ? gunzipSync(Buffer.from(bytes)).toString("utf-8") : "";
  }));
}

export async function GET() {
  try {
    const [cloudtrail, vpcFlow] = await Promise.all([
      getRecentLogs(CLOUDTRAIL_BUCKET, CLOUDTRAIL_PREFIX, 3),
      getRecentLogs(VPC_FLOW_LOG_BUCKET, VPC_FLOW_LOG_PREFIX, 3),
    ]);
    const cloudtrailEvents = cloudtrail.flatMap((file) => {
      try { return JSON.parse(file).Records ?? []; } catch { return []; }
    }).slice(0, 20);
    const vpcFlowLines = vpcFlow.flatMap((file) => file.trim().split("\n").filter(Boolean)).slice(0, 20);
    return NextResponse.json({ cloudtrailEvents, vpcFlowLines });
  } catch (error) {
    console.error("Unable to load security logs", error);
    return NextResponse.json({ error: "Unable to load security logs" }, { status: 502 });
  }
}
